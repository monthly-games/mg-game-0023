import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:mg_common_game/systems/systems.dart';
import 'package:mg_common_game/systems/gacha/gacha_pool.dart';
import 'package:mg_common_game/systems/gacha/gacha_manager.dart';
import 'package:mg_common_game/systems/battlepass/battlepass_config.dart';
import 'package:mg_common_game/systems/battlepass/battlepass_manager.dart';
import 'package:get_it/get_it.dart';
import 'package:provider/provider.dart';
import 'package:mg_common_game/systems/progression/upgrade_manager.dart';
import 'package:game/core/game_state.dart';
import 'package:game/core/population_manager.dart';
import 'package:game/core/building_manager.dart';
import 'package:game/screens/colony_screen.dart';
import 'package:mg_common_game/systems/progression/prestige_manager.dart';

// ═══════════════════════════════════════════════════════════════════════
// Colony Frontier — MG-0023
// Genre: Colony · Idle · Survival · Simulation · Strategy
// ═══════════════════════════════════════════════════════════════════════

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Dependency injection & data setup
  _registerManagers();
  _registerColonyUpgrades();
  _registerBuildingTemplates();

  // BattlePass 시스템
  GetIt.I.registerSingleton(BattlePassManager());
  // Gacha 시스템
  GetIt.I.registerSingleton(GachaManager());
  // Collection 시스템
  if (!GetIt.I.isRegistered<CollectionManager>()) {
    GetIt.I.registerSingleton(CollectionManager());
    _registerCollections();
  }
  _setupGacha();
  _setupBattlePass();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => GameState()),
        ChangeNotifierProvider.value(
          value: GetIt.I<UpgradeManager>(),
        ),
        ChangeNotifierProvider.value(
          value: GetIt.I<PopulationManager>(),
        ),
      ],
      child: const ColonyApp(),
    ),
  );
}

// ─── Manager Registration ──────────────────────────────────────────────
void _registerManagers() {
  final getIt = GetIt.I;

  getIt.registerSingleton<UpgradeManager>(UpgradeManager());
  getIt.registerSingleton<PopulationManager>(PopulationManager());
  getIt.registerSingleton<BuildingManager>(BuildingManager());

  // Prestige 시스템 (mg_common_game)
  if (!GetIt.I.isRegistered<PrestigeManager>()) {
    final prestigeManager = PrestigeManager();
    GetIt.I.registerSingleton(prestigeManager);
    _setupPrestige(prestigeManager);
  }
}

// ─── Colony Upgrade Definitions (8 upgrades) ───────────────────────────
/// Upgrades are purchased with Research points.
/// Each upgrade boosts a specific aspect of colony production or efficiency.
void _registerColonyUpgrades() {
  final um = GetIt.I<UpgradeManager>();

  // 1. Mining — iron production
  um.registerUpgrade(Upgrade(
    id: 'mining_drill',
    name: 'Mining Drill',
    description: 'Advanced drills increase iron output per building',
    maxLevel: 10,
    baseCost: 30,
    costMultiplier: 1.4,
    valuePerLevel: 0.15,
  ));

  // 2. Water — extraction rate
  um.registerUpgrade(Upgrade(
    id: 'water_purifier',
    name: 'Water Purifier',
    description: 'High-efficiency filters boost water extraction rate',
    maxLevel: 10,
    baseCost: 30,
    costMultiplier: 1.4,
    valuePerLevel: 0.15,
  ));

  // 3. Energy — solar output
  um.registerUpgrade(Upgrade(
    id: 'solar_array',
    name: 'Solar Array',
    description: 'Expanded solar collectors generate more energy',
    maxLevel: 10,
    baseCost: 25,
    costMultiplier: 1.35,
    valuePerLevel: 0.20,
  ));

  // 4. Food — crop yield
  um.registerUpgrade(Upgrade(
    id: 'crop_genetics',
    name: 'Crop Genetics',
    description: 'Bio-engineered seeds improve hydroponic food yield',
    maxLevel: 10,
    baseCost: 40,
    costMultiplier: 1.45,
    valuePerLevel: 0.15,
  ));

  // 5. Oxygen — reduced colonist O2 consumption
  um.registerUpgrade(Upgrade(
    id: 'air_recycler',
    name: 'Air Recycler',
    description: 'Recirculation system reduces oxygen consumption',
    maxLevel: 8,
    baseCost: 50,
    costMultiplier: 1.5,
    valuePerLevel: 0.10,
  ));

  // 6. Storage — all resource caps
  um.registerUpgrade(Upgrade(
    id: 'cargo_bay',
    name: 'Cargo Bay',
    description: 'Expanded modules increase all resource storage capacity',
    maxLevel: 10,
    baseCost: 35,
    costMultiplier: 1.4,
    valuePerLevel: 0.25,
  ));

  // 7. Research — output speed
  um.registerUpgrade(Upgrade(
    id: 'lab_equipment',
    name: 'Lab Equipment',
    description: 'Advanced instruments accelerate research output',
    maxLevel: 10,
    baseCost: 45,
    costMultiplier: 1.5,
    valuePerLevel: 0.20,
  ));

  // 8. Construction — build cost reduction
  um.registerUpgrade(Upgrade(
    id: 'prefab_modules',
    name: 'Prefab Modules',
    description: 'Pre-fabricated parts reduce building construction costs',
    maxLevel: 8,
    baseCost: 60,
    costMultiplier: 1.6,
    valuePerLevel: 0.08,
  ));
}

// ─── Building Template Definitions (8 templates) ───────────────────────
/// Templates define one-time construction cost, ongoing production,
/// ongoing consumption, storage bonuses, and housing capacity.
void _registerBuildingTemplates() {
  final bm = GetIt.I<BuildingManager>();

  bm.registerTemplate(const BuildingTemplate(
    id: 'solar_panel',
    name: 'Solar Panel',
    type: 'Energy',
    cost: {'iron': 10},
    production: {'energy': 1.0},
  ));

  bm.registerTemplate(const BuildingTemplate(
    id: 'water_extractor',
    name: 'Water Extractor',
    type: 'Water',
    cost: {'iron': 15},
    consumption: {'energy': 1.0},
    production: {'water': 1.0},
  ));

  bm.registerTemplate(const BuildingTemplate(
    id: 'oxygen_generator',
    name: 'O2 Generator',
    type: 'Oxygen',
    cost: {'iron': 20},
    consumption: {'energy': 1.0, 'water': 0.5},
    production: {'oxygen': 1.5},
  ));

  bm.registerTemplate(const BuildingTemplate(
    id: 'hydroponic_farm',
    name: 'Hydroponic Farm',
    type: 'Food',
    cost: {'iron': 25},
    consumption: {'water': 1.0, 'energy': 1.0},
    production: {'food': 1.0},
    requiredTech: 'tech_hydro',
  ));

  bm.registerTemplate(const BuildingTemplate(
    id: 'research_lab',
    name: 'Research Lab',
    type: 'Research',
    cost: {'iron': 30},
    consumption: {'energy': 2.0},
    production: {'research': 1.0},
  ));

  bm.registerTemplate(const BuildingTemplate(
    id: 'warehouse',
    name: 'Warehouse',
    type: 'Storage',
    cost: {'iron': 20},
    storageIncrease: {
      'iron': 100,
      'water': 100,
      'oxygen': 100,
      'energy': 100,
      'food': 100,
    },
  ));

  bm.registerTemplate(const BuildingTemplate(
    id: 'habitat',
    name: 'Habitat Module',
    type: 'Housing',
    cost: {'iron': 40},
    consumption: {'energy': 2.0},
    housingCapacity: 10,
  ));

  bm.registerTemplate(const BuildingTemplate(
    id: 'nuclear_reactor',
    name: 'Nuclear Reactor',
    type: 'Energy',
    cost: {'iron': 100},
    production: {'energy': 50.0},
    requiredTech: 'tech_adv_power',
  ));
}

// ─── App Widget ────────────────────────────────────────────────────────
class ColonyApp extends StatelessWidget {
  const ColonyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Colony Frontier',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: const Color(0xFF0F172A),
        useMaterial3: true,
        cardTheme: const CardThemeData(
          color: Color(0xFF1E293B),
          elevation: 2,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0F172A),
          elevation: 0,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFF3B82F6),
          foregroundColor: Colors.white,
        ),
        snackBarTheme: const SnackBarThemeData(
          backgroundColor: Color(0xFF334155),
          contentTextStyle: TextStyle(color: Colors.white),
        ),
      ),
      home: const ColonyScreen(),
    );
  }
}


void _setupBattlePass() {
  final bp = GetIt.I<BattlePassManager>();

  final season = BPSeasonBuilder.create28DaySeason(
    id: 'season_1',
    nameKr: '시즌 1',
    startDate: DateTime.now().subtract(const Duration(days: 1)),
    maxLevel: 50,
    expPerLevel: 1000,
  );

  bp.setSeason(season);
  bp.setMissions(
    daily: BPSeasonBuilder.createDefaultDailyMissions(),
    weekly: BPSeasonBuilder.createDefaultWeeklyMissions(),
  );
}


void _setupGacha() {
  final gacha = GetIt.I<GachaManager>();

  gacha.registerPool(GachaPool(
    id: 'standard_pool',
    nameKr: '스탠다드 뽑기',
    items: [
      // N (50%)
      ...List.generate(20, (i) => GachaItem(
        id: 'n_item_$i',
        nameKr: '일반 아이템 $i',
        rarity: GachaRarity.normal,
      )),

      // R (35%)
      ...List.generate(10, (i) => GachaItem(
        id: 'r_item_$i',
        nameKr: '레어 아이템 $i',
        rarity: GachaRarity.rare,
      )),

      // SR (12%)
      ...List.generate(5, (i) => GachaItem(
        id: 'sr_item_$i',
        nameKr: '슈퍼레어 아이템 $i',
        rarity: GachaRarity.superRare,
      )),

      // SSR (2.7%)
      GachaItem(
        id: 'ssr_item_1',
        nameKr: '울트라레어 아이템 1',
        rarity: GachaRarity.ultraRare,
      ),

      // UR (0.3%)
      GachaItem(
        id: 'ur_item_1',
        nameKr: '레전더리 아이템 1',
        rarity: GachaRarity.legendary,
      ),
    ],
  ));
}

void _setupPrestige(PrestigeManager manager) {
  // ── Prestige Upgrades (idle game defaults) ──────────────────
  // Five core upgrades for idle games
  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'gold_multiplier',
    name: '골드 배수',
    description: '골드 획득량 +10%',
    maxLevel: 50,
    costPerLevel: 1,
    bonusPerLevel: 0.1,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'xp_boost',
    name: 'XP 부스트',
    description: 'XP 획득량 +15%',
    maxLevel: 40,
    costPerLevel: 2,
    bonusPerLevel: 0.15,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'production_speed',
    name: '생산 속도',
    description: '생산 속도 +20%',
    maxLevel: 30,
    costPerLevel: 2,
    bonusPerLevel: 0.2,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'starting_resources',
    name: '초기 자원',
    description: '초기 자원 +5%',
    maxLevel: 60,
    costPerLevel: 1,
    bonusPerLevel: 0.05,
  ));

  manager.registerPrestigeUpgrade(PrestigeUpgrade(
    id: 'offline_income',
    name: '오프라인 수익',
    description: '오프라인 수익 +20%',
    maxLevel: 30,
    costPerLevel: 3,
    bonusPerLevel: 0.2,
  ));

  // ── Prestige Reset Callbacks ────────────────────────────────
  // TODO: Add game-specific reset callbacks:
  // manager.registerResetCallback(() {
  //   if (GetIt.I.isRegistered<ProgressionManager>()) {
  //     GetIt.I<ProgressionManager>().reset();
  //   }
  //   if (GetIt.I.isRegistered<UpgradeManager>()) {
  //     GetIt.I<UpgradeManager>().reset();
  //   }
  // });
}

void _registerCollections() {
  final collection = GetIt.I<CollectionManager>();

  // Characters 컬렉션
  collection.registerCollection(const Collection(
    id: 'characters',
    name: '캐릭터',
    description: '모든 캐릭터를 수집하세요',
    items: [
      CollectionItem(
        id: 'char_warrior',
        name: '전사',
        description: '강인한 근접 전투 캐릭터',
        rarity: CollectionRarity.common,
      ),
      CollectionItem(
        id: 'char_mage',
        name: '마법사',
        description: '강력한 마법 공격 캐릭터',
        rarity: CollectionRarity.rare,
      ),
      CollectionItem(
        id: 'char_archer',
        name: '궁수',
        description: '원거리 정밀 공격 캐릭터',
        rarity: CollectionRarity.rare,
      ),
      CollectionItem(
        id: 'char_assassin',
        name: '암살자',
        description: '치명적인 은신 공격 캐릭터',
        rarity: CollectionRarity.epic,
      ),
      CollectionItem(
        id: 'char_healer',
        name: '힐러',
        description: '팀을 치유하는 지원 캐릭터',
        rarity: CollectionRarity.legendary,
      ),
    ],
    completionReward: CollectionReward(gold: 10000, gems: 500, experience: 2000),
    milestoneRewards: {
      25: CollectionReward(gold: 1000, gems: 50),
      50: CollectionReward(gold: 3000, gems: 150),
      75: CollectionReward(gold: 5000, gems: 300),
    },
  ));

  // 아이템 해제 콜백 (햅틱 피드백)
  collection.onItemUnlocked = (collectionId, itemId) {
    // SettingsManager가 등록되어 있으면 햅틱 피드백
    debugPrint('Collection item unlocked: $collectionId / $itemId');
  };
}
